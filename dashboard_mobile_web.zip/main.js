import React from 'https://esm.sh/react';
import { createRoot } from 'https://esm.sh/react-dom/client';

function App() {
  return (
    <div>
      <h1 style={{textAlign:'center'}}>Dashboard Mobile</h1>
      <div class='card'>Frotas em dia: 42</div>
      <div class='card'>Pendentes: 3</div>
      <div class='card'>Relatórios: 45</div>
      <div class='navbar'>
        <span>🏠</span><span>🚌</span><span>📊</span><span>⚙️</span>
      </div>
    </div>
  );
}

createRoot(document.getElementById("root")).render(<App />);
